# for i in range(1, 11):
#     print(i)
#     if i >= 5:
#         break

# for i in range(1,11):
#     if i == 5:
#         continue    
#     print(i)

for i in range(1, 11):
    if i == 5:
        pass
    print(i)
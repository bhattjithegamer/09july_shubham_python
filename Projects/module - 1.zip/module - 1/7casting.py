a=50.5
print(int(a))


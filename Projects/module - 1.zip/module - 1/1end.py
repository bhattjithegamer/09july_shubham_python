print("hello",end=" ")
print("bhattji")

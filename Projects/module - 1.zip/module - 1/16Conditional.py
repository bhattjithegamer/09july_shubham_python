
#if
# a = 10
# if a == 10:
#     print("a is 10")


# if elif
# a = int(input("enter your marks: "))

# if a >= 90:
#     print("a+")
# elif a >= 70:
#     print("b+")
# elif a >= 50:
#     print("c+")
# elif a >= 40:
#     print("d+")
# else:
#     print("f")


# nested if
age = int(input("enter your age : "))
if age >= 18:
    print("u r eligible to vote",end= " - ")
    if age >=50:
        print("senior cho tme")
else:
    print("u r not eligible to vote")
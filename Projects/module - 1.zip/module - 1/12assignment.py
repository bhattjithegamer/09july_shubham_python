a=45
print(a)

a+=10
print(a)

a-=10
print(a)
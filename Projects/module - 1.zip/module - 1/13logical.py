#and
# age = int(input("enter age: "))

# if age >= 18 and age <= 65:
#     print("You are eligible to vote.")
#     if age >= 50:
#         print("You are eligible for senior citizen benefits.")
# elif age >= 66:
#     print("bs ho have")
# else:
#     print("You are not eligible to vote.")


# or
# age = int(input("enter your age : "))

# if age <= 17 or age >=1:
#     print("u cant't vote")
# else:
#     print("u can vote")

#not
# age = int(input("enter your age : "))
# if not age > 18:
#     print("You are not eligible to vote.")
# else:
#     print("You are eligible to vote.")
    
age=22
name="bhattji"

print(f"age is {age} and your name is {name}")
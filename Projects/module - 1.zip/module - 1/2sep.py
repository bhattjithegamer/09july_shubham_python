print("hello", "my self", "shubham","bhatt",sep="\n")
print("Hi","Hello","This is Python!",sep="\n")
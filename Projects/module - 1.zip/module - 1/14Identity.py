# x = int(input("Enter a number: "))

# if x is 5:
#     print("true")
# else:
#     print("false")

x = int(input("Enter a number: "))

if x is not 5:
    print("true")
else:
    print("false")
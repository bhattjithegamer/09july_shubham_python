a=int(input("enter your age : "))
b=(input("enter your name : "))

print("your age is",a)
print("your name is",b)
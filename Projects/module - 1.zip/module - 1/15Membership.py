# a = [10]
# if 10 in a:
#     print("yes there is ")
# else:
#     print("no there is not")

a = [10]
if 10 not in a:
    print("yes there is ")
else:
    print("no there is not")
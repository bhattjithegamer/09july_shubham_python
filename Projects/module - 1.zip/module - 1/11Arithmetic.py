a=int(input("enter first"))
b=int(input("enter second"))

print(f"Addition: {a + b}")
print(f"Subtraction: {a - b}")
print(f"Mul {a * b}")
print(f"div {a / b}")
print(f"mod {a % b}")
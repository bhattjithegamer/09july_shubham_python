print(r"shubham\nbhatt")  # Raw string to avoid escape sequence processing
print(R"shubham\nbhatt")  # Raw string to avoid escape sequence processing
a=10
b=45

c=a+b
print(f"{a}+{b}={c}")

name="shubham"
print(f"hello my name is {name}")
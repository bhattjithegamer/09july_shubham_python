a=10
b=1.5
c="bhattji"
d=True

print(type(a))
print(type(b))
print(type(c))
print(type(d))

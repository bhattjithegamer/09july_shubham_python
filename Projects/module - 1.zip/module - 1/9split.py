a="hello there is 5 type of inheritance in python:"
print(a)
print(a.split("i"))
print(a.split("h"))
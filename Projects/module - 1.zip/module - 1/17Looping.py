# for i in range(1,11):
#     print(i)

# for i in range(11):
#     print(i)

# for i in range(1, 11, 2):
#     print(i)

# for i in range(10, 0, -1):
#     print(i)

# for i in range(2, 11, 2):
#     print(i)

# i = 1
# while i <= 10:
#     print(i)
#     i += 1

# i = 1
# while i <= 10:
#     print(i)
#     i += 2

# i = 2
# while i <= 10:
#     print(i)
#     i += 2

# i = 1
# while i <= 10:
#     print("bhatt ji",i)
#     i += 1

i = 1
n = 5
while i <= 10:
    print(f"{n}*{i}={n*i}")
    i += 1